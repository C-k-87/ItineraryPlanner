import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class Map_2 extends JFrame {
    
    private JLabel imageLabel;
    private JScrollPane scrollPane;
    private double zoomLevel = 1.0;
    
    public Map_2() {
        super("Zoomable Image");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Load the image and create a label to hold it
        ImageIcon image = new ImageIcon("./src/Images/largeMap.jpg");
        imageLabel = new JLabel(image);
        
        // Create a panel to hold the label and add it to a scroll pane
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(imageLabel, BorderLayout.CENTER);
        scrollPane = new JScrollPane(panel);
        getContentPane().add(scrollPane, BorderLayout.CENTER);
        
        // Add a mouse listener to the label to handle zooming
        imageLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    // Double-click to reset zoom level
                    zoomLevel = 1.0;
                } else {
                    // Single-click to zoom in
                    zoomLevel *= 1.5;
                }
                // Update the label size and scroll position
                updateImageLabel();
            }
        });
        
        pack();
        setLocationRelativeTo(null);
        //setVisible(true);
    }
    
    private void updateImageLabel() {
        // Get the current scroll position and image size
        int scrollX = scrollPane.getHorizontalScrollBar().getValue();
        int scrollY = scrollPane.getVerticalScrollBar().getValue();
        int imageWidth = (int) (imageLabel.getIcon().getIconWidth() * zoomLevel);
        int imageHeight = (int) (imageLabel.getIcon().getIconHeight() * zoomLevel);
        
        // Set the new label size and update the scroll position
        imageLabel.setPreferredSize(new Dimension(imageWidth, imageHeight));
        scrollPane.getViewport().revalidate();
        scrollPane.getHorizontalScrollBar().setValue(scrollX);
        scrollPane.getVerticalScrollBar().setValue(scrollY);
    }
    
    
     public void run() {
        Map_2 frame = new Map_2();
        frame.setSize(1000, 800);
        frame.setLocation(250, 0);
        frame.setVisible(true);
    }
    public static void main(String[] args) {
        new Map_2();
    }
}

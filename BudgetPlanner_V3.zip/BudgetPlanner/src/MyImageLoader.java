/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jayas
 */
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class MyImageLoader {
    public static BufferedImage loadImage(String filename) throws IOException {
        // Load the image from a file
        BufferedImage originalImage = ImageIO.read(new File(filename));

        // Create a new BufferedImage with the same dimensions as the original image
        BufferedImage newImage = new BufferedImage(originalImage.getWidth(), originalImage.getHeight(), BufferedImage.TYPE_INT_RGB);

        // Draw the original image onto the new BufferedImage
        newImage.createGraphics().drawImage(originalImage, 0, 0, null);

        return newImage;
    }
}

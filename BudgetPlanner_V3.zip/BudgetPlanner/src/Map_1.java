/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jayas
 */
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Map_1 extends JFrame {

    private static final long serialVersionUID = 1L;
    private BufferedImage image;
    private double scale = 1;

    public Map_1() {
        super("Zoomable JFrame");
        try {
            image = ImageIO.read(new File("./src/Images/largeMap.jpg"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(500, 500);
        setContentPane(new JPanel() {
            private static final long serialVersionUID = 1L;

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.scale(scale, scale);
                g2.drawImage(image, 0, 0, null);
            }
        });
        addMouseWheelListener(new MouseAdapter() {
            @Override
            public void mouseWheelMoved(MouseWheelEvent e) {
                if (e.getWheelRotation() < 0) {
                    scale += 0.1;
                } else {
                    scale -= 0.1;
                }
                repaint();
            }
        });
    }
    
     public void run() {
        Map_1 frame = new Map_1();
        frame.setSize(1000, 900);
        frame.setLocation(250, 0);
        frame.setVisible(true);
    }
     
    public static void main(String[] args) {
        Map_1 frame = new Map_1();
        frame.setSize(1000, 900);
        frame.setLocation(250, 0);
        frame.setVisible(true);
    }
}

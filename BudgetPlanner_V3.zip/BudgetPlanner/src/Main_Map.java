/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jayas
 */
import javax.swing.*;
import java.awt.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;



public class Main_Map extends JFrame {
    
    public void run() {
        
        JFrame frame = new JFrame();
        JScrollPane scrollPane = new JScrollPane();
        JPanel panel = new JPanel();

        // Set the layout manager for the panel
        panel.setLayout(new BorderLayout());

        // Load the image file and create an ImageIcon object
        ImageIcon icon = new ImageIcon("./src/Images/largeMap.jpg");

        // Create a JLabel and set the image icon as the icon for the label
        JLabel label = new JLabel(icon);
        panel.add(label, BorderLayout.CENTER);

        // Create a JSlider and set its properties
        JSlider slider = new JSlider(JSlider.HORIZONTAL, 100, 200, 100);
        slider.setMajorTickSpacing(50);
        slider.setMinorTickSpacing(10);
        slider.setPaintTicks(true);
        slider.setPaintLabels(true);

        // Add a change listener to the slider
        slider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                // Get the value of the slider and set the scale of the label accordingly
                int value = slider.getValue();
                double scale = value / 100.0;
                label.setPreferredSize(new Dimension((int)(icon.getIconWidth() * scale), (int)(icon.getIconHeight() * scale)));
                panel.revalidate();
            }
        });

        // Add the slider to the JFrame
        frame.getContentPane().add(slider, BorderLayout.NORTH);

        // Add the panel to the JScrollPane and add the JScrollPane to the JFrame
        scrollPane.setViewportView(panel);
        frame.getContentPane().add(scrollPane, BorderLayout.CENTER);

        // Set the properties of the JFrame and display it
        frame.setTitle("Road Map of SriLanka");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(1000, 800);
        frame.setLocation(250, 0);
        frame.setVisible(true);
    }
    

}

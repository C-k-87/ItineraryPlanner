/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jayas
 */
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.swing.*;

public class MyFrame extends JFrame {
    public MyFrame() throws IOException {
        // Create a new JLabel
        JLabel label = new JLabel();

        // Load the image without scaling it
        BufferedImage image = MyImageLoader.loadImage("./src/Images/kt.jpg");

        // Set the image as the icon of the label
        label.setIcon(new ImageIcon(image));

        // Add the label to the frame
        getContentPane().add(label);

        // Set the size and visibility of the frame
        setSize(766, 523);
        setVisible(true);
    }

    public static void main (String[] args)throws IOException {
        // Create a new instance of the frame
        MyFrame frame = new MyFrame();
    }
    
}

